
export interface CameraProfile {
  id: string;
  name: string;
  prompt: string;
}

export interface FilmLook {
  id: string;
  name: string;
  prompt: string;
}
