
import React from 'react';
import { Spinner } from './Spinner';

interface ImageViewerProps {
  originalImage: string | null | undefined;
  processedImage: string | null;
  isLoading: boolean;
}

const ImageFrame: React.FC<{ title: string; imageUrl: string | null; isLoading?: boolean; isPlaceholder?: boolean; children?: React.ReactNode }> = ({ title, imageUrl, isLoading, isPlaceholder, children }) => (
    <div className="w-full flex flex-col">
        <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase mb-3 text-center">{title}</h3>
        <div className="relative aspect-w-16 aspect-h-9 w-full bg-gray-800 rounded-xl shadow-inner overflow-hidden flex items-center justify-center">
            {imageUrl && <img src={imageUrl} alt={title} className="object-contain w-full h-full" />}
            {isPlaceholder && !imageUrl && (
                 <div className="text-gray-500 text-center p-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    <p className="mt-2">{title === "Original" ? "Upload an image to begin" : "Your graded image will appear here"}</p>
                </div>
            )}
            {isLoading && (
                <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center text-white">
                    <Spinner />
                    <p className="mt-4 text-lg">Applying grade...</p>
                    <p className="mt-1 text-sm text-gray-300">AI is thinking, this may take a moment.</p>
                </div>
            )}
            {children}
        </div>
    </div>
);


export const ImageViewer: React.FC<ImageViewerProps> = ({ originalImage, processedImage, isLoading }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8 items-start">
        <ImageFrame title="Original" imageUrl={originalImage} isPlaceholder={true}/>
        <ImageFrame title="Graded" imageUrl={processedImage} isLoading={isLoading} isPlaceholder={true}>
            {processedImage && (
                <a
                    href={processedImage}
                    download="graded-image.png"
                    className="absolute bottom-4 right-4 bg-white/20 hover:bg-white/30 backdrop-blur-lg text-white font-semibold py-2 px-4 rounded-full flex items-center space-x-2 transition-all"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                    <span>Download</span>
                </a>
            )}
        </ImageFrame>
    </div>
  );
};
