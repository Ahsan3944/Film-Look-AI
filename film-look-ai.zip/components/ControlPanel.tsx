
import React from 'react';
import type { CameraProfile, FilmLook } from '../types';
import { Spinner } from './Spinner';

interface ControlPanelProps {
  cameraProfiles: CameraProfile[];
  filmLooks: FilmLook[];
  selectedCamera: string;
  selectedFilm: string;
  onCameraChange: (id: string) => void;
  onFilmChange: (id: string) => void;
  onApply: () => void;
  isLoading: boolean;
  onNewImage: () => void;
}

const SelectInput: React.FC<{ label: string; value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; children: React.ReactNode; }> = ({ label, value, onChange, children }) => (
    <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">{label}</label>
        <div className="relative">
            <select
                value={value}
                onChange={onChange}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
                {children}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </div>
        </div>
    </div>
);


export const ControlPanel: React.FC<ControlPanelProps> = ({
  cameraProfiles,
  filmLooks,
  selectedCamera,
  selectedFilm,
  onCameraChange,
  onFilmChange,
  onApply,
  isLoading,
  onNewImage
}) => {
  return (
    <div className="flex flex-col space-y-6 h-full">
      <h2 className="text-xl font-semibold text-white">Color Grade Settings</h2>
      
      <div className="space-y-4">
        <SelectInput 
            label="1. Camera Profile"
            value={selectedCamera}
            onChange={(e) => onCameraChange(e.target.value)}
        >
          {cameraProfiles.map(profile => (
            <option key={profile.id} value={profile.id}>{profile.name}</option>
          ))}
        </SelectInput>
        
        <SelectInput 
            label="2. Film Look"
            value={selectedFilm}
            onChange={(e) => onFilmChange(e.target.value)}
        >
          {filmLooks.map(look => (
            <option key={look.id} value={look.id}>{look.name}</option>
          ))}
        </SelectInput>
      </div>

      <div className="flex-grow"></div>

      <div className="space-y-3">
        <button
          onClick={onApply}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
        >
          {isLoading ? <Spinner /> : 'Apply Grade'}
        </button>
        <button
          onClick={onNewImage}
          disabled={isLoading}
          className="w-full bg-gray-600 hover:bg-gray-500 text-gray-200 font-bold py-2 px-4 rounded-lg transition-colors duration-300 disabled:opacity-50"
        >
          Upload New Image
        </button>
      </div>
    </div>
  );
};
